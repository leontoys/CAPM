/*
 * node-cache 4.1.0 ( 2016-12-21 )
 * https://github.com/mpneuried/nodecache
 *
 * Released under the MIT license
 * https://github.com/mpneuried/nodecache/blob/master/LICENSE
 *
 * Maintained by M. Peter ( https://github.com/mpneuried )
*/
(function() {
  var exports;

  exports = module.exports = require('./lib/node_cache');

  exports.version = '4.1.0';

}).call(this);

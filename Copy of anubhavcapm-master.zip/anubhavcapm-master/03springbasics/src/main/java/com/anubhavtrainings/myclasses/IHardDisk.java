package com.anubhavtrainings.myclasses;

public interface IHardDisk {
	@Override
	public String toString();
	public void powerOnHDD();
	public void powerOffHDD();
	public void readHDD();
}
